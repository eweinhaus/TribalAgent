# merchants

**Database:** postgres_production
**Schema:** public
**Description:** This table represents merchant entities in the system, storing basic information about business merchants or service providers. Each merchant is uniquely identified by a merchant_id (primary key) and includes a timestamp tracking when the merchant record was created. The table appears to serve as a foundational reference table for merchants, though it currently has no established relationships with other tables in the database schema.

## Columns

| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| merchant_id | character varying | NO | A unique identifier for business establishments, represented as human-readable names that describe the type of business or establishment name. Based on the sample data, this includes various service businesses such as restaurants, gyms, bookstores, and golf clubs. |
| created_at | timestamp without time zone | YES | Records the timestamp when each merchant record was initially added to the system. Based on the sample data, this appears to track merchant registration or onboarding dates. |

## Primary Key

`merchant_id`

## Indexes

- `merchants_pkey`: CREATE UNIQUE INDEX merchants_pkey ON public.merchants USING btree (merchant_id)

## Sample Data

| merchant_id | created_at |
| --- | --- |
| Crossfit_Hanna | Tue Dec 09 2025 21:38:08 GMT-0600 (Central Stan... |
| Martinis_Fine_Steakhouse | Tue Dec 09 2025 21:38:08 GMT-0600 (Central Stan... |
| Belles_cookbook_store | Tue Dec 09 2025 21:38:08 GMT-0600 (Central Stan... |
| Golfclub_Baron_Friso | Tue Dec 09 2025 21:38:08 GMT-0600 (Central Stan... |
| Rafa_AI | Tue Dec 09 2025 21:38:08 GMT-0600 (Central Stan... |

*Generated at: 2025-12-12T23:55:56.980Z*