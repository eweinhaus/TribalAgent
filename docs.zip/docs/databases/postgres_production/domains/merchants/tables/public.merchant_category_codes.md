# merchant_category_codes

**Database:** postgres_production
**Schema:** public
**Description:** This table serves as a reference catalog for Merchant Category Codes (MCCs), storing standardized industry classification codes with their corresponding business category descriptions. Based on the sample data showing MCC code "1520" for "General Contractors - Residential and Commercial", this table maintains the mapping between numeric MCC identifiers and their human-readable business category names, with timestamps indicating when each record was created. The table functions as a standalone lookup repository with no foreign key relationships, suggesting it serves as a master reference for categorizing merchants or transactions by industry type across the broader application.

**Row Count:** 769

## Columns

| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| mcc_code | character varying | NO | A standardized four-digit code that categorizes merchants by their primary business type or industry, used for payment processing and transaction classification. Based on the sample values, this includes codes for construction contractors, general contractors, and publishing services. |
| category_description | text | YES | Contains detailed business activity descriptions that explain the specific types of services or products offered within each merchant category, such as construction specialties, contracting services, and printing operations. |
| created_at | timestamp without time zone | YES | Records the timestamp when each merchant category code record was first inserted into the database. All sample values show the same December 9, 2025 timestamp, suggesting these records were created during a bulk data load operation. |

## Primary Key

`mcc_code`

## Indexes

- `merchant_category_codes_pkey`: CREATE UNIQUE INDEX merchant_category_codes_pkey ON public.merchant_category_codes USING btree (mcc_code)

## Sample Data

| mcc_code | category_description | created_at |
| --- | --- | --- |
| 1520 | General Contractors - Residential and Commercial | Tue Dec 09 2025 21:38:07 GMT-0600 (Central Stan... |
| 1711 | Heating, Plumbing, and Air Conditioning Contrac... | Tue Dec 09 2025 21:38:07 GMT-0600 (Central Stan... |
| 1731 | Electrical Contractors | Tue Dec 09 2025 21:38:07 GMT-0600 (Central Stan... |
| 1740 | Masonry, Stonework, Tile-Setting, Plastering, a... | Tue Dec 09 2025 21:38:07 GMT-0600 (Central Stan... |
| 1750 | Carpentry Contractors | Tue Dec 09 2025 21:38:07 GMT-0600 (Central Stan... |

*Generated at: 2025-12-12T23:55:58.143Z*