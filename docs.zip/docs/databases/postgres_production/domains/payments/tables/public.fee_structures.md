# fee_structures

**Database:** postgres_production
**Schema:** public
**Description:** The `fee_structures` table stores payment processing fee configurations, with each record containing a unique identifier and a JSON object that defines fee parameters including rates, fixed amounts, card schemes, merchant category codes, and various processing conditions. This table appears to serve as a reference system for determining transaction fees based on merchant characteristics and payment attributes such as card type (ACI codes), transaction volume, and merchant category. The table operates independently without foreign key relationships, suggesting it functions as a standalone configuration repository for fee calculation logic.

**Row Count:** 1,000

## Columns

| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| fee_id | integer | NO | A unique identifier that automatically assigns sequential numbers to each fee structure record in the system. Based on the sample values, this serves as the primary key for distinguishing between different fee arrangements. |
| fee_data | jsonb | YES | Purpose unclear from available data. Contains structured data objects that likely define various fee calculation parameters or pricing information, but the specific business meaning cannot be determined from the generic object references shown. |
| created_at | timestamp without time zone | YES | Records the exact date and time when each fee structure record was initially added to the system. Based on the sample values, all entries appear to have been created simultaneously on the same date in December 2025. |

## Primary Key

`fee_id`

## Indexes

- `fee_structures_pkey`: CREATE UNIQUE INDEX fee_structures_pkey ON public.fee_structures USING btree (fee_id)

## Sample Data

| fee_id | fee_data | created_at |
| --- | --- | --- |
| 1 | [object Object] | Tue Dec 09 2025 21:38:09 GMT-0600 (Central Stan... |
| 2 | [object Object] | Tue Dec 09 2025 21:38:09 GMT-0600 (Central Stan... |
| 3 | [object Object] | Tue Dec 09 2025 21:38:09 GMT-0600 (Central Stan... |
| 4 | [object Object] | Tue Dec 09 2025 21:38:09 GMT-0600 (Central Stan... |
| 5 | [object Object] | Tue Dec 09 2025 21:38:09 GMT-0600 (Central Stan... |

*Generated at: 2025-12-12T23:56:06.874Z*