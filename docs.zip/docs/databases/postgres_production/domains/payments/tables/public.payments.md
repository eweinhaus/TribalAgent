# payments

**Database:** postgres_production
**Schema:** public
**Description:** This table represents payment transactions processed through a payment system, storing detailed information about each financial transaction including merchant details, card information, transaction amounts, and fraud detection results. The table serves as a central transaction log capturing payment processing data across different merchants, countries, and device types, with built-in fraud monitoring capabilities through the is_fraudulent flag. Based on the comprehensive transaction metadata including acquirer information, IP geolocation, and card details, this appears to be a core operational table for a payment processing platform handling e-commerce and other digital transactions.

**Row Count:** 138,236

## Columns

| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| payment_id | character varying | NO | Unique identifier assigned to each payment transaction, represented as an 11-digit numeric string. Serves as the primary reference number for tracking and managing individual payment records in the system. |
| merchant_id | character varying | YES | A text identifier that specifies which business or organization is receiving the payment. Based on the sample data, this includes various types of merchants such as fitness facilities, retail stores, golf clubs, and AI services. |
| card_brand | character varying | YES | Stores the brand or network name of the payment card used for the transaction. Based on the sample data, this includes various card processing networks such as GlobalCard, SwiftCharge, TransactPlus, and NexPay. |
| transaction_amount | numeric | YES | Stores the monetary value of individual payment transactions, representing amounts that customers have paid or attempted to pay. Values appear to represent typical consumer transaction amounts ranging from small purchases under $30 to larger transactions of several hundred dollars. |
| issuing_country | character varying | YES | Stores the two-letter country code indicating where the payment method or card was issued. Based on the sample data, this includes European countries such as Netherlands, Sweden, Spain, Belgium, and Italy. |
| device_type | character varying | YES | Records the operating system or platform type of the device used to process the payment transaction. Based on the sample data, this captures whether payments were made from mobile devices running Android or iOS, desktop systems running Linux, or other unspecified platforms. |
| shopper_interaction | character varying | YES | Indicates the type of interaction channel through which the customer initiated the payment transaction. Based on the sample data, values include "Ecommerce" for online transactions and "POS" for point-of-sale terminal transactions. |
| card_bin | character varying | YES | Stores the first 4-6 digits of payment card numbers, which identify the issuing bank and card type. Based on the sample values starting with 4, these appear to be Bank Identification Numbers (BINs) primarily from Visa cards. |
| is_fraudulent | boolean | YES | Indicates whether a payment transaction has been identified or flagged as fraudulent activity. Based on the sample data, the vast majority of payments are legitimate with only occasional instances of fraud detection. |
| is_refused | boolean | YES | Indicates whether a payment transaction was declined or rejected during processing. Based on the sample data showing all false values, this tracks the refusal status with most payments being successfully accepted. |
| aci | character varying | YES | Based on the sample values (single letters F, D, C, G, E), this appears to represent a classification or status code system for payments. Purpose unclear from available data beyond being a categorical identifier using alphabetic codes. |
| acquirer_country_code | character varying | YES | Stores the two-letter country code indicating the country where the payment acquirer (processing entity) is located. Based on the sample data, payments are processed through acquirers in the Netherlands, United States, and Italy. |
| ip_country | character varying | YES | Stores the two-letter country code indicating the geographic location associated with the IP address used during the payment transaction. Based on the sample data, this captures European countries where payments originated from. |
| created_at | timestamp without time zone | YES | Records the exact date and time when each payment record was initially created in the system. Automatically captures the timestamp at the moment of record insertion to provide an audit trail of when payment transactions were first logged. |

## Primary Key

`payment_id`

## Indexes

- `idx_payments_card_brand`: CREATE INDEX idx_payments_card_brand ON public.payments USING btree (card_brand)
- `idx_payments_merchant_id`: CREATE INDEX idx_payments_merchant_id ON public.payments USING btree (merchant_id)
- `payments_pkey`: CREATE UNIQUE INDEX payments_pkey ON public.payments USING btree (payment_id)

## Sample Data

| payment_id | merchant_id | card_brand | transaction_amount | issuing_country | device_type | shopper_interaction | card_bin | is_fraudulent | is_refused | aci | acquirer_country_code | ip_country | created_at |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 10000636248 | Crossfit_Hanna | GlobalCard | 58.66 | NL | Linux | Ecommerce | 4571 | false | false | F | NL | BE | Tue Dec 09 2025 21:39:28 GMT-0600 (Central Stan... |
| 10001482390 | Belles_cookbook_store | GlobalCard | 36.62 | SE | Android | Ecommerce | 4556 | false | false | D | US | SE | Tue Dec 09 2025 21:39:28 GMT-0600 (Central Stan... |
| 10001579064 | Golfclub_Baron_Friso | GlobalCard | 130.67 | ES | Other | POS | 4556 | false | false | C | IT | ES | Tue Dec 09 2025 21:39:28 GMT-0600 (Central Stan... |
| 10002494026 | Crossfit_Hanna | SwiftCharge | 229.73 | BE | Android | Ecommerce | 4916 | false | false | F | NL | BE | Tue Dec 09 2025 21:39:28 GMT-0600 (Central Stan... |
| 10002671296 | Golfclub_Baron_Friso | TransactPlus | 748.91 | IT | Android | Ecommerce | 4891 | false | false | D | IT | BE | Tue Dec 09 2025 21:39:28 GMT-0600 (Central Stan... |

*Generated at: 2025-12-12T23:56:08.288Z*