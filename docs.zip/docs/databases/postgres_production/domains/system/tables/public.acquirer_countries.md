# acquirer_countries

**Database:** postgres_production
**Schema:** public
**Description:** The `acquirer_countries` table represents a reference list of countries where payment acquirers operate, with each record identified by a two-character country code (such as "GB" for Great Britain) and tracking when the country record was created. This table appears to serve as a standalone reference data entity for geographic coverage of payment acquisition services, as it has no foreign key relationships with other tables. The table functions as a foundational lookup table in what is likely a payment processing or financial services data model.

## Columns

| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| country_code | character varying | NO | Stores two-letter country codes identifying the countries where acquirers operate. Based on the sample values, this includes major markets such as Great Britain, United States, Netherlands, Italy, and France. |
| created_at | timestamp without time zone | YES | Records the timestamp when each acquirer country record was first inserted into the database. Based on the sample values, all entries appear to have been created on the same date in December 2025. |

## Primary Key

`country_code`

## Indexes

- `acquirer_countries_pkey`: CREATE UNIQUE INDEX acquirer_countries_pkey ON public.acquirer_countries USING btree (country_code)

## Sample Data

| country_code | created_at |
| --- | --- |
| GB | Tue Dec 09 2025 21:38:08 GMT-0600 (Central Stan... |
| US | Tue Dec 09 2025 21:38:08 GMT-0600 (Central Stan... |
| NL | Tue Dec 09 2025 21:38:08 GMT-0600 (Central Stan... |
| IT | Tue Dec 09 2025 21:38:08 GMT-0600 (Central Stan... |
| FR | Tue Dec 09 2025 21:38:08 GMT-0600 (Central Stan... |

*Generated at: 2025-12-12T23:56:39.233Z*