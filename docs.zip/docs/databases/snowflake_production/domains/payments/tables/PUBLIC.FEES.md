# FEES

**Database:** snowflake_production
**Schema:** PUBLIC
**Description:** This table represents fee structures or pricing configurations for payment processing services, storing rate and pricing information associated with different card schemes, merchant category codes, and account characteristics. Based on the sample data showing fields like CARD_SCHEME, MERCHANT_CATEGORY_CODE, FIXED_AMOUNT, RATE, and payment-related attributes (IS_CREDIT, ACI, CAPTURE_DELAY), this appears to be a reference table that defines fee calculations for transaction processing. The table operates independently with no foreign key relationships, suggesting it serves as a standalone configuration or lookup table for determining applicable fees based on transaction characteristics.

**Row Count:** 1,194

## Columns

| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| ID | NUMBER | YES | A numeric identifier that assigns unique sequential numbers to fee records, with values appearing to follow an ascending pattern in the 600-800 range. |
| CARD_SCHEME | TEXT | YES | Identifies the payment processing network or system used to handle card transactions, with values including NexPay, TransactPlus, and SwiftCharge. This likely categorizes fees based on which payment scheme processed the transaction. |
| ACCOUNT_TYPE | VARIANT | YES | Stores a classification code that appears to categorize accounts, with observed values including 'F' and 'R' alongside many null entries. Purpose unclear from available data due to limited sample diversity and lack of additional context. |
| CAPTURE_DELAY | TEXT | YES | Indicates the timing or delay period for capturing fee payments, with values ranging from immediate processing to manual intervention required. The delay periods are expressed as day ranges (e.g., "<3", "3-5", ">5") or processing type descriptors. |
| MONTHLY_FRAUD_LEVEL | TEXT | YES | Represents the monthly fraud rate category expressed as percentage ranges, indicating the level of fraudulent activity within specific timeframes. The values suggest a tiered classification system with ranges like 7.2%-7.7%, 7.7%-8.3%, and >8.3% used to categorize fraud exposure levels. |
| MONTHLY_VOLUME | TEXT | YES | Categorizes entities into volume-based tiers using ranges that appear to represent monetary amounts, with buckets including less than 100k, 100k-1m, 1m-5m, and greater than 5m. Used for segmenting clients or transactions by their monthly transaction volume levels. |
| MERCHANT_CATEGORY_CODE | VARIANT | YES | Contains comma-separated four-digit codes that classify merchant business types, such as automotive dealers (4111, 4121), gas stations (5411, 5412), restaurants (5812, 5813), and healthcare services (8011, 8021). These standardized industry classification codes are used to categorize the types of businesses associated with fee transactions. |
| IS_CREDIT | BOOLEAN | YES | Indicates whether a fee entry represents a credit transaction that reduces the amount owed or increases an account balance, as opposed to a debit that increases charges or reduces balances. |
| ACI | VARIANT | YES | Contains categorical codes using letters A through D, with some entries having multiple comma-separated values and others being empty. Purpose unclear from available data, though appears to be some form of classification or rating system related to fee processing. |
| FIXED_AMOUNT | FLOAT | YES | Represents a monetary fee or charge amount, likely in the base currency unit, with values typically ranging from one cent to several cents. Based on the small decimal values, this appears to be either a fixed transaction fee or a percentage-based fee expressed as a decimal. |
| RATE | NUMBER | YES | Represents a numerical rate value associated with fees, likely expressing percentages, basis points, or other rate measurements ranging from 14 to 84 based on the sample data. The specific unit of measurement and business context cannot be determined from the available information. |
| INTRACOUNTRY | TEXT | YES | Indicates whether a fee applies to transactions occurring within the same country, with 1 representing domestic/intracountry transactions and 0 representing cross-border transactions. |

## Sample Data

| ID | CARD_SCHEME | ACCOUNT_TYPE | CAPTURE_DELAY | MONTHLY_FRAUD_LEVEL | MONTHLY_VOLUME | MERCHANT_CATEGORY_CODE | IS_CREDIT | ACI | FIXED_AMOUNT | RATE | INTRACOUNTRY |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 836 | NexPay |  | null | null | null | 4111,4121,4131,4411,4511,4789,7513,7523 | false | C,A | 0.06 | 84 | 1 |
| 835 | TransactPlus |  | null | null | >5m | 5734,5735,5736,5816,5912,7399,5964,5999 | false | A,B | 0.13 | 30 | 1 |
| 837 | TransactPlus | F,R | immediate | null | null | 8062,8011,8021,7231,7298,7991,8049 | true | A,B | 0.06 | 50 | 1 |
| 834 | SwiftCharge |  | null | null | null | 5411,5412,5499,5912,5812,5813,5911,5983 | true | D | 0.08 | 20 | 0 |
| 832 | TransactPlus |  | <3 | null | 1m-5m | 4111,4121,4131,4411,4511,4789,7513,7523 | true |  | 0.04 | 52 | 1 |

*Generated at: 2025-12-12T23:56:30.155Z*