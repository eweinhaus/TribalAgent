# PAYMENTS

**Database:** snowflake_production
**Schema:** PUBLIC
**Description:** This table represents payment transaction records processed through a payment service provider system, capturing detailed information about individual payment attempts including merchant details, card schemes, geographical data, and fraud indicators. Based on the PSP_REFERENCE field and columns like MERCHANT, CARD_SCHEME, EUR_AMOUNT, and fraud-related flags (HAS_FRAUDULENT_DISPUTE, IS_REFUSED_BY_ADYEN), this appears to be a central transaction log for payment processing operations. The table operates independently without foreign key relationships, suggesting it serves as a comprehensive transaction repository that aggregates payment data from various sources for analysis and monitoring purposes.

**Row Count:** 138,236

## Columns

| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| PSP_REFERENCE | NUMBER | YES | A unique numeric identifier assigned by the payment service provider to track and reference specific payment transactions. Based on the sample values, these appear to be system-generated reference numbers used for payment processing and reconciliation purposes. |
| MERCHANT | TEXT | YES | Identifies the business or organization that received the payment. Based on the sample data, this includes fitness facilities, retail stores, and recreational clubs. |
| CARD_SCHEME | TEXT | YES | Identifies the payment card network or processing scheme used for the transaction. Based on the sample data, this includes networks such as NexPay, GlobalCard, SwiftCharge, and TransactPlus. |
| YEAR | NUMBER | YES | Represents the calendar year when a payment transaction occurred or was processed. Based on the sample data, all payments shown were made in 2023. |
| HOUR_OF_DAY | NUMBER | YES | Represents the specific hour (0-23) when a payment transaction occurred during the day. Based on the sample values, payments are processed throughout various times including early morning, business hours, and late evening. |
| MINUTE_OF_HOUR | NUMBER | YES | Records the minute component (0-59) of the hour when a payment transaction occurred. Based on the sample values, this appears to capture the precise timing of payments within each hour for temporal analysis purposes. |
| DAY_OF_YEAR | NUMBER | YES | Represents the sequential day number within a calendar year when a payment transaction occurred, ranging from 1 (January 1st) to 365/366 (December 31st). Based on the sample values, payments are distributed throughout the year from early January (day 5) to late September (day 265). |
| IS_CREDIT | BOOLEAN | YES | Indicates whether a payment transaction represents a credit to an account, as opposed to a debit or charge. Based on the sample data, approximately half of the payment records are credits while the other half are not. |
| EUR_AMOUNT | FLOAT | YES | Represents the monetary value of payments denominated in Euros. Based on the sample values ranging from approximately 13 to 238 Euros, this appears to capture transaction amounts of varying sizes. |
| IP_COUNTRY | TEXT | YES | Records the two-letter country code indicating the geographic location associated with the IP address used during the payment transaction. Based on the sample data, this appears to track payments originating from European countries including Sweden, Netherlands, and Luxembourg. |
| ISSUING_COUNTRY | TEXT | YES | Stores the two-letter country code indicating the country where the payment instrument (such as a credit card or bank account) was issued. Based on the sample data, this includes European countries such as Sweden, Netherlands, Luxembourg, and Belgium. |
| DEVICE_TYPE | TEXT | YES | Records the operating system or platform type of the device used when processing the payment transaction. Captures whether the payment was made from a desktop operating system (Windows, Linux, MacOS) or mobile platform (iOS, Android). |
| IP_ADDRESS | TEXT | YES | Contains encoded or hashed identifiers that appear to be base64-encoded strings, likely representing anonymized or encrypted IP addresses for privacy protection. Purpose unclear from available data beyond being some form of obfuscated network identifier. |
| EMAIL_ADDRESS | TEXT | YES | Purpose unclear from available data. Contains encoded or hashed alphanumeric values that do not appear to be readable email addresses. |
| CARD_NUMBER | TEXT | YES | Contains encrypted or hashed representations of payment card numbers used to process customer transactions while maintaining security and privacy compliance. |
| SHOPPER_INTERACTION | TEXT | YES | Indicates the type of interaction or channel through which the shopper engaged during the payment process. Based on the sample data, this appears to primarily capture e-commerce transactions conducted online. |
| CARD_BIN | NUMBER | YES | First six digits of a payment card number used to identify the issuing bank and card type. Based on the sample values starting with 4, this appears to primarily contain Visa card identifiers. |
| HAS_FRAUDULENT_DISPUTE | BOOLEAN | YES | Indicates whether a payment has been subject to a dispute that was determined to be fraudulent. Based on the sample data, the vast majority of payments do not have fraudulent disputes associated with them. |
| IS_REFUSED_BY_ADYEN | BOOLEAN | YES | Indicates whether a payment transaction was declined or rejected by the Adyen payment processing system. Based on the sample data showing all false values, this tracks instances where Adyen did not refuse the payment requests. |
| ACI | TEXT | YES | Based on the sample values containing single letters (F, D, G), this appears to be a categorical code or classification system for payments. Purpose unclear from available data without additional context about what these letter codes represent. |
| ACQUIRER_COUNTRY | TEXT | YES | Stores the two-letter country code representing the country where the payment acquirer (the financial institution processing the payment) is located. Based on the sample data, this includes countries such as the Netherlands, United States, and Italy. |

## Sample Data

| PSP_REFERENCE | MERCHANT | CARD_SCHEME | YEAR | HOUR_OF_DAY | MINUTE_OF_HOUR | DAY_OF_YEAR | IS_CREDIT | EUR_AMOUNT | IP_COUNTRY | ISSUING_COUNTRY | DEVICE_TYPE | IP_ADDRESS | EMAIL_ADDRESS | CARD_NUMBER | SHOPPER_INTERACTION | CARD_BIN | HAS_FRAUDULENT_DISPUTE | IS_REFUSED_BY_ADYEN | ACI | ACQUIRER_COUNTRY |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20034594130 | Crossfit_Hanna | NexPay | 2023 | 16 | 21 | 12 | false | 151.74 | SE | SE | Windows | pKPYzJqqwB8TdpY0jiAeQw | 0AKXyaTjW7H4m1hOWmOKBQ | uRofX46FuLUrSOTz8AW5UQ | Ecommerce | 4802 | false | false | F | NL |
| 36926127356 | Crossfit_Hanna | NexPay | 2023 | 23 | 58 | 75 | false | 45.7 | NL | NL | Linux | uzUknOkIqExYsWv4X14GUg | _Gm8at1k2ojYAM_wSEptNw | 6vqQ89zfCeFk6s4VOoWZFQ | Ecommerce | 4920 | false | false | F | NL |
| 31114608278 | Belles_cookbook_store | GlobalCard | 2023 | 4 | 30 | 96 | false | 14.11 | NL | NL | MacOS | 3VO1v_RndDg6jzEiPjfvoQ | null | EmxSN8-GXQw3RG_2v7xKxQ | Ecommerce | 4571 | false | false | F | US |
| 68442235288 | Crossfit_Hanna | NexPay | 2023 | 3 | 5 | 77 | true | 238.42 | LU | LU | iOS | 3qbuXGoFldniCC6r1X8K0Q | 5VW_2O6ku_0p_fLLwuC1vw | wG2VTvj2TfVG-NRDzifMHw | Ecommerce | 4017 | false | false | D | NL |
| 81404384199 | Crossfit_Hanna | NexPay | 2023 | 17 | 30 | 83 | false | 67.13 | NL | NL | Windows | 9WMJJdgtop6jkkyerxMvuQ | Alb1iUIxIqlW8YUeYVGTzg | 0khzuCj7aQ1e51S5vWR8gg | Ecommerce | 4532 | false | false | F | NL |

*Generated at: 2025-12-12T23:56:32.340Z*