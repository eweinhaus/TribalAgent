# MERCHANT_CATEGORY_CODES

**Database:** snowflake_production
**Schema:** PUBLIC
**Description:** This table serves as a reference catalog for Merchant Category Codes (MCCs), storing standardized industry classification codes used to categorize merchant businesses. Each row contains an MCC numeric code paired with its corresponding business description, such as code 1520 for "General Contractors - Residential and Commercial." The table functions as a lookup dimension in the data model, likely used to classify and categorize merchant transactions or business entities throughout the system.

**Row Count:** 769

## Columns

| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| COL_1 | NUMBER | YES | A sequential numeric identifier or index value ranging from 0 to 9. Purpose unclear from available data without additional context about how these numbers relate to merchant category codes. |
| MCC | NUMBER | YES | A standardized four-digit classification code that categorizes merchants by their primary business type or industry, such as construction, contracting, and publishing services as shown in the sample values. |
| DESCRIPTION | TEXT | YES | Contains detailed textual descriptions of various business categories and industry classifications, primarily focused on construction, contracting, and professional services. These descriptions appear to define the specific types of businesses or activities associated with standardized merchant category codes. |

## Sample Data

| COL_1 | MCC | DESCRIPTION |
| --- | --- | --- |
| 0 | 1520 | General Contractors - Residential and Commercial |
| 1 | 1711 | Heating, Plumbing, and Air Conditioning Contrac... |
| 2 | 1731 | Electrical Contractors |
| 3 | 1740 | Masonry, Stonework, Tile-Setting, Plastering, a... |
| 4 | 1750 | Carpentry Contractors |

*Generated at: 2025-12-12T23:56:17.682Z*