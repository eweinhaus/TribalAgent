# MERCHANT_DATA

**Database:** snowflake_production
**Schema:** PUBLIC
**Description:** This table stores merchant configuration data for payment processing, containing 30 merchant records with details about payment capture settings, associated financial institutions, and merchant classification codes. Each merchant has a manual or automated capture delay setting, multiple acquirer banks for payment processing, an MCC (Merchant Category Code) for business categorization, and an account type designation. The table appears to serve as a reference for merchant onboarding and payment routing configuration within the payment processing system.

**Row Count:** 30

## Columns

| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| MERCHANT | TEXT | YES | Stores the business name or identifier for various commercial establishments including restaurants, fitness facilities, bookstores, golf clubs, and other service providers. Based on the sample data, these appear to be merchant partners or vendors in a business transaction system. |
| CAPTURE_DELAY | TEXT | YES | Specifies the delay period for capturing payment transactions, with values indicating either manual processing, immediate capture, or a specific number of days to wait before capture. |
| ACQUIRER | VARIANT | YES | Stores the names of financial institutions or banks that process payment transactions for merchants, with multiple acquirers separated by commas when applicable. Based on the sample data, these include both fictional banks from popular culture and real financial institutions. |
| MERCHANT_CATEGORY_CODE | NUMBER | YES | A numeric code that categorizes merchants by their business type or industry, with values like 7997, 5812, 5942, 7993, and 7372 representing different merchant categories. Based on the four-digit format, this appears to follow standard merchant category code classification systems used in payment processing. |
| ACCOUNT_TYPE | TEXT | YES | Categorizes merchants using single-letter codes, with observed values including F, H, R, and D that likely represent different business or operational classifications. Purpose unclear from available data without additional context about what these letter codes signify. |

## Sample Data

| MERCHANT | CAPTURE_DELAY | ACQUIRER | MERCHANT_CATEGORY_CODE | ACCOUNT_TYPE |
| --- | --- | --- | --- | --- |
| Crossfit_Hanna | manual | gringotts,the_savings_and_loan_bank,bank_of_spr... | 7997 | F |
| Martinis_Fine_Steakhouse | immediate | dagoberts_geldpakhuis,bank_of_springfield | 5812 | H |
| Belles_cookbook_store | 1 | lehman_brothers | 5942 | R |
| Golfclub_Baron_Friso | 2 | medici | 7993 | F |
| Rafa_AI | 7 | tellsons_bank | 7372 | D |

*Generated at: 2025-12-12T23:56:17.153Z*